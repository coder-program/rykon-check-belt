/**
 * Henry TCP Bridge - Rykon Check Belt
 * 
 * Este script roda em um computador LOCAL na mesma rede da catraca.
 * Conecta na catraca Henry via TCP e repassa os eventos para o backend na nuvem.
 * 
 * Como funciona:
 * 1. Conecta na catraca (192.168.100.163:3000)
 * 2. Quando a catraca enviaa matrícula de um aluno que passou
 * 3. O script chama o backend Railway via HTTP
 * 4. Responde à catraca se deve liberar ou bloquear
 */

const net = require('net');
const https = require('https');
const http = require('http');

// ============================================================
// CONFIGURAÇÃO - EDITE AQUI
// ============================================================
const CONFIG = {
  // IP e porta da catraca Henry
  catraca: {
    ip: '192.168.100.163',
    port: 3000,
  },

  // URL do backend no Railway (ou outro cloud)
  backend: {
    url: 'https://rykon-check-belt-production.up.railway.app',
    endpoint: '/api/catraca/webhook',
    api_key: 'chave_secreta_henry8x_itapevi',
  },

  // ID da unidade no sistema
  unidade_id: '8863d9de-b350-4c8f-a930-726b1df3261f',

  // Reconectar na catraca se cair a conexão
  reconnect_delay_ms: 5000,

  // Timeout para chamar o backend (ms)
  backend_timeout_ms: 2500,
};
// ============================================================

// Formato padrão Henry: %IIIIIIIII[%CCC[%RRRRRRRRRRRRRRRRRRRR[%DD/%MM/%AAAA %hh:%mm:%ss[%O[%S}%FFF[%TT[%o
// Exemplo:              000000594[000[               000001[19/02/2026 17:31:56[1[1}000[03[1
//
// Tokens:
//  I = índice do evento
//  C = código de acesso
//  R/U = matrícula do usuário
//  D/M/A = data
//  h/m/s = hora
//  O = direção (1=entrada, 2=saída)
//  S = acesso (1=liberado, 0=negado)
//  F = função
//  T = tipo de entrada
//  o = flag online (1=já foi validado online, 0=offline)

function parseHenryEvent(linha) {
  try {
    // Remove espaços e quebras de linha
    linha = linha.trim();
    if (!linha) return null;

    // Separador principal é '['
    const partes = linha.split('[');
    if (partes.length < 6) return null;

    const index = partes[0]?.trim();
    const codigo = partes[1]?.trim();
    const matricula = partes[2]?.trim(); // pode ter espaços na frente
    const dataHora = partes[3]?.trim();
    const direcao = partes[4]?.trim();
    
    // Parte 5 pode ser "1}000" (acesso + função separados por '}')
    const acessoFuncao = partes[5]?.split('}');
    const acesso = acessoFuncao?.[0]?.trim();
    const funcao = acessoFuncao?.[1]?.trim();

    const tipoOnline = partes[6]?.split('[');

    return {
      index: index?.replace(/^0+/, '') || '0',
      codigo,
      matricula: matricula?.trim(),
      dataHora,
      direcao: direcao === '1' ? 'ENTRADA' : direcao === '2' ? 'SAIDA' : direcao,
      acesso: acesso === '1' ? 'LIBERADO' : acesso === '0' ? 'NEGADO' : acesso,
      funcao,
      raw: linha,
    };
  } catch (err) {
    return { raw: linha, erro: err.message };
  }
}

function log(msg, meta) {
  const ts = new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });
  if (meta) {
    console.log(`[${ts}] ${msg}`, meta);
  } else {
    console.log(`[${ts}] ${msg}`);
  }
}

function chamarBackend(matricula) {
  return new Promise((resolve) => {
    const payload = JSON.stringify({
      matricula: matricula,
      unidade_id: CONFIG.unidade_id,
      dispositivo_id: `HENRY_${CONFIG.catraca.ip}`,
      api_key: CONFIG.backend.api_key,
      timestamp: new Date().toISOString(),
    });

    const urlCompleta = CONFIG.backend.url + CONFIG.backend.endpoint;
    const isHttps = urlCompleta.startsWith('https://');
    const urlObj = new URL(urlCompleta);

    const options = {
      hostname: urlObj.hostname,
      port: urlObj.port || (isHttps ? 443 : 80),
      path: urlObj.pathname,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload),
      },
      timeout: CONFIG.backend_timeout_ms,
    };

    const lib = isHttps ? https : http;
    const req = lib.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => (data += chunk));
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch {
          resolve({ success: false, liberar_catraca: false, mensagem_display: 'ERRO JSON' });
        }
      });
    });

    req.on('error', (err) => {
      log(`❌ Erro ao chamar backend: ${err.message}`);
      resolve({ success: false, liberar_catraca: false, mensagem_display: 'SEM CONEXAO' });
    });

    req.on('timeout', () => {
      req.destroy();
      log(`⏱️ Timeout ao chamar backend`);
      resolve({ success: false, liberar_catraca: false, mensagem_display: 'TIMEOUT' });
    });

    req.write(payload);
    req.end();
  });
}

// Buffer para acumular dados parciais da conexão TCP
let buffer = '';

async function processarLinha(linha, socket) {
  const evento = parseHenryEvent(linha);
  if (!evento) return;

  log(`📥 Evento recebido:`, evento);

  const matricula = evento.matricula;
  if (!matricula || matricula === '0' || matricula.replace(/0/g, '') === '') {
    log(`⚠️ Matrícula inválida ou vazia: "${matricula}" - ignorando`);
    // Responde allow para não bloquear passagem sem matrícula
    socket.write('\x01');
    return;
  }

  log(`🔍 Buscando aluno com matrícula: ${matricula}`);

  const resposta = await chamarBackend(matricula);

  if (resposta.liberar_catraca) {
    log(`✅ LIBERAR - Aluno: ${resposta.nome_aluno || matricula} | ${resposta.mensagem_display || ''}`);
    // Resposta Henry: 1 byte 0x01 = liberar
    socket.write('\x01');
  } else {
    log(`🚫 BLOQUEAR - ${resposta.message || resposta.mensagem_display || 'Acesso negado'}`);
    // Resposta Henry: 1 byte 0x00 = bloquear
    socket.write('\x00');
  }
}

function conectarCatraca() {
  log(`🔌 Conectando na catraca ${CONFIG.catraca.ip}:${CONFIG.catraca.port} ...`);

  const socket = new net.Socket();

  socket.setTimeout(30000); // 30 segundos de timeout de inatividade

  socket.connect(CONFIG.catraca.port, CONFIG.catraca.ip, () => {
    log(`✅ Conectado na catraca Henry!`);
    buffer = '';
  });

  socket.on('data', (data) => {
    const raw = data.toString('utf8');
    log(`📡 Dados brutos recebidos (${data.length} bytes):`, JSON.stringify(raw));
    log(`📡 Hex:`, data.toString('hex'));

    // Acumula no buffer
    buffer += raw;

    // Processa linhas completas (terminadas em \n ou \r\n)
    const linhas = buffer.split(/\r?\n/);
    // Guarda o que não está completo ainda
    buffer = linhas.pop() || '';

    for (const linha of linhas) {
      if (linha.trim()) {
        processarLinha(linha, socket).catch((err) => {
          log(`❌ Erro ao processar linha: ${err.message}`);
        });
      }
    }
  });

  socket.on('error', (err) => {
    log(`❌ Erro na conexão TCP: ${err.message}`);
  });

  socket.on('timeout', () => {
    log(`⏱️ Conexão ociosa (30s) - mantendo conectado...`);
    // Envia keepalive
    socket.write('\x00');
  });

  socket.on('close', () => {
    log(`🔴 Conexão com a catraca fechada. Reconectando em ${CONFIG.reconnect_delay_ms / 1000}s...`);
    setTimeout(conectarCatraca, CONFIG.reconnect_delay_ms);
  });
}

// ============================================================
// INÍCIO
// ============================================================
log(`=======================================================`);
log(`   Henry Bridge - Rykon Check Belt`);
log(`=======================================================`);
log(`Catraca: ${CONFIG.catraca.ip}:${CONFIG.catraca.port}`);
log(`Backend: ${CONFIG.backend.url}`);
log(`Unidade: ${CONFIG.unidade_id}`);
log(`=======================================================`);

if (CONFIG.backend.url.includes('SEU-APP')) {
  console.error('\n🚨 ERRO: Configure a URL do backend no arquivo henry-bridge.js!');
  console.error('   Edite a linha: url: \'https://SEU-APP.railway.app\'');
  console.error('   Substitua pela URL real do seu backend Railway.\n');
  process.exit(1);
}

conectarCatraca();
